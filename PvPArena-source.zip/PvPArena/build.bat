@echo off
rem Needs JDK 21 and Maven. Jar ends up in target\PvPArena-1.2.0.jar
mvn -B package
pause
