package dev.pvparena;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class KitManager {

    private final JavaPlugin plugin;
    private final File file;
    private final Map<String, Kit> kits = new LinkedHashMap<>();

    KitManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "kits.yml");
    }

    void load() {
        kits.clear();
        if (!file.exists()) {
            for (Kit k : DefaultKits.create()) kits.put(k.name(), k);
            save();
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("kits");
        if (root == null) return;
        for (String name : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(name);
            if (s == null) continue;
            Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
            if (icon == null) icon = Material.CHEST;
            ItemStack[] contents = new ItemStack[41];
            List<?> raw = s.getList("contents", new ArrayList<>());
            for (int i = 0; i < raw.size() && i < 41; i++)
                contents[i] = raw.get(i) instanceof ItemStack is ? is : null;
            List<PotionEffect> effects = new ArrayList<>();
            for (Object o : s.getList("effects", new ArrayList<>()))
                if (o instanceof PotionEffect pe) effects.add(pe);
            kits.put(name.toLowerCase(), new Kit(name.toLowerCase(), s.getString("display", name), icon, contents, effects));
        }
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Kit k : kits.values()) {
            String p = "kits." + k.name();
            y.set(p + ".display", k.display());
            y.set(p + ".icon", k.icon().name());
            y.set(p + ".contents", Arrays.asList(k.contents()));
            y.set(p + ".effects", k.effects());
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save kits.yml: " + e.getMessage());
        }
    }

    Kit get(String name) {
        return name == null ? null : kits.get(name.toLowerCase());
    }

    Collection<Kit> all() {
        return kits.values();
    }

    List<String> names() {
        return new ArrayList<>(kits.keySet());
    }

    boolean delete(String name) {
        boolean r = kits.remove(name.toLowerCase()) != null;
        if (r) save();
        return r;
    }

    /** Save the player's current inventory + potion effects as a kit. */
    Kit create(String name, Player p) {
        ItemStack[] src = p.getInventory().getContents();
        ItemStack[] c = new ItemStack[41];
        for (int i = 0; i < src.length && i < 41; i++) c[i] = src[i] == null ? null : src[i].clone();
        Material icon = p.getInventory().getItemInMainHand().getType();
        if (icon.isAir() || !icon.isItem()) icon = Material.CHEST;
        String lower = name.toLowerCase();
        String display = Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
        Kit k = new Kit(lower, display, icon, c, new ArrayList<>(p.getActivePotionEffects()));
        kits.put(lower, k);
        save();
        return k;
    }

    void apply(Player p, Kit k, boolean clearEffects) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        ItemStack[] copy = new ItemStack[41];
        for (int i = 0; i < 41 && i < k.contents().length; i++)
            copy[i] = k.contents()[i] == null ? null : k.contents()[i].clone();
        inv.setContents(copy);
        if (clearEffects)
            for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
        for (PotionEffect e : k.effects()) p.addPotionEffect(e);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
    }
}
