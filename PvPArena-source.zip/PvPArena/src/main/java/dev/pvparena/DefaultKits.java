package dev.pvparena;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.bukkit.Material.*;

/** Default kits, one per PvP style. Edit kits.yml afterwards, or use /kit create. */
final class DefaultKits {

    private DefaultKits() {}

    private static final Enchantment SHARP = Enchantment.SHARPNESS;
    private static final Enchantment PROT = Enchantment.PROTECTION;
    private static final Enchantment BLAST = Enchantment.BLAST_PROTECTION;
    private static final Enchantment UNB = Enchantment.UNBREAKING;
    private static final Enchantment MEND = Enchantment.MENDING;
    private static final Enchantment FF = Enchantment.FEATHER_FALLING;
    private static final Enchantment POWER = Enchantment.POWER;
    private static final Enchantment PUNCH = Enchantment.PUNCH;
    private static final Enchantment FLAME = Enchantment.FLAME;
    private static final Enchantment INF = Enchantment.INFINITY;
    private static final Enchantment PIERCE = Enchantment.PIERCING;
    private static final Enchantment QC = Enchantment.QUICK_CHARGE;
    private static final Enchantment DENS = Enchantment.DENSITY;
    private static final Enchantment WIND = Enchantment.WIND_BURST;
    private static final Enchantment EFF = Enchantment.EFFICIENCY;
    // Spears / Lunge only exist on 1.21.11+. Looked up by name so the same jar
    // still loads on older 1.21.x servers (the spear kits are simply skipped).
    private static final Material SPEAR = Material.matchMaterial("NETHERITE_SPEAR");
    private static final Enchantment LUNGE = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("lunge"));

    static List<Kit> create() {
        List<Kit> l = new ArrayList<>();
        l.add(sword());
        l.add(axe());
        l.add(pot());
        l.add(nethpot());
        l.add(debuff());
        l.add(crystal());
        l.add(uhc());
        l.add(mace());
        addIf(l, spear());
        l.add(elytraMace());
        addIf(l, elytraSpear());
        l.add(archer());
        l.add(sumo());
        l.add(buildffa());
        l.add(gapple());
        return l;
    }

    private static void addIf(List<Kit> l, Kit k) {
        if (k != null) l.add(k);
    }

    // ------------------------------------------------------------------ kits

    private static Kit sword() {
        List<ItemStack> i = list(
                e(DIAMOND_SWORD, 1, SHARP, 3, UNB, 3),
                e(BOW, 1, POWER, 2, UNB, 3),
                it(GOLDEN_APPLE, 16), it(COOKED_BEEF, 32), it(ARROW, 32),
                it(ENDER_PEARL, 4), it(WATER_BUCKET, 1));
        return kit("sword", "Sword", DIAMOND_SWORD, armor("DIAMOND", PROT, 3), it(SHIELD, 1), i);
    }

    private static Kit axe() {
        List<ItemStack> i = list(
                e(NETHERITE_AXE, 1, SHARP, 5, UNB, 3),
                e(NETHERITE_SWORD, 1, SHARP, 4, UNB, 3),
                it(GOLDEN_APPLE, 12), it(COOKED_BEEF, 32), it(ENDER_PEARL, 4), it(COBWEB, 8));
        return kit("axe", "Axe / Shield", NETHERITE_AXE, armor("DIAMOND", PROT, 4), it(SHIELD, 1), i);
    }

    private static Kit pot() {
        List<ItemStack> i = list(
                e(DIAMOND_SWORD, 1, SHARP, 4, UNB, 3),
                it(ENDER_PEARL, 16), it(GOLDEN_APPLE, 8),
                potion(false, PotionEffectType.SPEED, 9600, 1, "Speed II", Color.AQUA),
                potion(false, PotionEffectType.FIRE_RESISTANCE, 9600, 0, "Fire Resistance", Color.ORANGE));
        fillSplash(i);
        return kit("pot", "Pot PvP", SPLASH_POTION, armor("DIAMOND", PROT, 4), null, i);
    }

    private static Kit nethpot() {
        List<ItemStack> i = list(
                e(NETHERITE_SWORD, 1, SHARP, 5, UNB, 3, Enchantment.FIRE_ASPECT, 2),
                it(ENDER_PEARL, 16), it(GOLDEN_APPLE, 16),
                potion(false, PotionEffectType.STRENGTH, 3600, 1, "Strength II", Color.MAROON),
                potion(false, PotionEffectType.SPEED, 9600, 1, "Speed II", Color.AQUA),
                potion(false, PotionEffectType.FIRE_RESISTANCE, 9600, 0, "Fire Resistance", Color.ORANGE),
                it(TOTEM_OF_UNDYING, 1));
        fillSplash(i);
        return kit("nethpot", "Netherite Pot", NETHERITE_SWORD, armor("NETHERITE", PROT, 4), it(TOTEM_OF_UNDYING, 1), i);
    }

    private static Kit debuff() {
        List<ItemStack> i = list(
                e(DIAMOND_SWORD, 1, SHARP, 4, UNB, 3),
                it(ENDER_PEARL, 16), it(GOLDEN_APPLE, 8),
                potion(false, PotionEffectType.SPEED, 9600, 1, "Speed II", Color.AQUA),
                potion(true, PotionEffectType.POISON, 440, 1, "Splash Poison II", Color.GREEN),
                potion(true, PotionEffectType.POISON, 440, 1, "Splash Poison II", Color.GREEN),
                potion(true, PotionEffectType.SLOWNESS, 400, 3, "Splash Slowness IV", Color.GRAY),
                potion(true, PotionEffectType.SLOWNESS, 400, 3, "Splash Slowness IV", Color.GRAY),
                potion(true, PotionEffectType.WEAKNESS, 1800, 0, "Splash Weakness", Color.SILVER),
                potion(true, PotionEffectType.WEAKNESS, 1800, 0, "Splash Weakness", Color.SILVER));
        fillSplash(i);
        return kit("debuff", "Debuff Pot", SPIDER_EYE, armor("DIAMOND", PROT, 4), null, i);
    }

    private static Kit crystal() {
        List<ItemStack> i = list(
                e(NETHERITE_SWORD, 1, SHARP, 5, UNB, 3),
                it(OBSIDIAN, 64), it(OBSIDIAN, 64),
                it(END_CRYSTAL, 64), it(END_CRYSTAL, 64),
                it(ENDER_PEARL, 16), it(GOLDEN_APPLE, 32), it(EXPERIENCE_BOTTLE, 64),
                it(TOTEM_OF_UNDYING, 1), it(TOTEM_OF_UNDYING, 1), it(TOTEM_OF_UNDYING, 1));
        return kit("crystal", "Crystal PvP", END_CRYSTAL, armor("NETHERITE", BLAST, 4), it(TOTEM_OF_UNDYING, 1), i);
    }

    private static Kit uhc() {
        List<ItemStack> i = list(
                e(DIAMOND_SWORD, 1, SHARP, 3, UNB, 3),
                it(FISHING_ROD, 1),
                e(BOW, 1, POWER, 3, UNB, 3),
                it(GOLDEN_APPLE, 6),
                it(LAVA_BUCKET, 1), it(WATER_BUCKET, 1), it(WATER_BUCKET, 1),
                it(COBBLESTONE, 64), it(COBBLESTONE, 64), it(OAK_PLANKS, 64),
                it(ARROW, 32), it(COOKED_BEEF, 32),
                e(DIAMOND_PICKAXE, 1, EFF, 3), e(DIAMOND_AXE, 1, EFF, 3));
        return kit("uhc", "UHC", LAVA_BUCKET, armor("DIAMOND", PROT, 3), it(SHIELD, 1), i);
    }

    private static Kit mace() {
        List<ItemStack> i = list(
                e(MACE, 1, DENS, 5, WIND, 3, UNB, 3),
                it(WIND_CHARGE, 64),
                it(GOLDEN_APPLE, 16), it(COBWEB, 16), it(WATER_BUCKET, 1), it(ENDER_PEARL, 8),
                it(TOTEM_OF_UNDYING, 1));
        return kit("mace", "Mace", MACE, armor("NETHERITE", PROT, 4), it(TOTEM_OF_UNDYING, 1), i);
    }


    private static Kit spear() {
        if (SPEAR == null) return null;
        List<ItemStack> i = list(
                e(SPEAR, 1, SHARP, 5, LUNGE, 3, UNB, 3, MEND, 1),
                it(GOLDEN_APPLE, 16), it(COOKED_BEEF, 32), it(ENDER_PEARL, 8),
                it(COBWEB, 8), it(WATER_BUCKET, 1), it(TOTEM_OF_UNDYING, 1));
        return kit("spear", "Spear", SPEAR, armor("NETHERITE", PROT, 4), it(SHIELD, 1), i);
    }

    private static Kit elytraMace() {
        ItemStack[] a = armor("NETHERITE", PROT, 4);
        a[2] = e(ELYTRA, 1, UNB, 3, MEND, 1);
        List<ItemStack> i = list(
                e(MACE, 1, DENS, 5, WIND, 3, UNB, 3, MEND, 1),
                rockets(64), rockets(64),
                it(WIND_CHARGE, 64),
                it(GOLDEN_APPLE, 16), it(ENDER_PEARL, 8), it(COBWEB, 8), it(WATER_BUCKET, 1),
                it(TOTEM_OF_UNDYING, 1));
        return kit("elytramace", "Elytra Mace", ELYTRA, a, it(TOTEM_OF_UNDYING, 1), i);
    }

    private static Kit elytraSpear() {
        if (SPEAR == null) return null;
        ItemStack[] a = armor("NETHERITE", PROT, 4);
        a[2] = e(ELYTRA, 1, UNB, 3, MEND, 1);
        // Lunge doesn't work while gliding, so rely on diving speed + rockets.
        List<ItemStack> i = list(
                e(SPEAR, 1, SHARP, 5, LUNGE, 3, UNB, 3, MEND, 1),
                rockets(64), rockets(64),
                it(GOLDEN_APPLE, 16), it(ENDER_PEARL, 8), it(COBWEB, 8), it(WATER_BUCKET, 1),
                it(TOTEM_OF_UNDYING, 1));
        return kit("elytraspear", "Elytra Spear", SPEAR, a, it(TOTEM_OF_UNDYING, 1), i);
    }

    private static Kit archer() {
        List<ItemStack> i = list(
                e(BOW, 1, POWER, 5, PUNCH, 2, FLAME, 1, INF, 1, UNB, 3),
                e(CROSSBOW, 1, PIERCE, 4, QC, 3, UNB, 3),
                it(ARROW, 64),
                e(IRON_SWORD, 1, SHARP, 2),
                it(GOLDEN_APPLE, 8), it(COBWEB, 8), it(ENDER_PEARL, 4), it(WATER_BUCKET, 1));
        return kit("archer", "Archer", BOW, armor("IRON", PROT, 3), null, i,
                new PotionEffect(PotionEffectType.SPEED, 24000, 0, false, false));
    }

    private static Kit sumo() {
        // Empty hands, immune to damage: knock your opponent off the platform.
        return kit("sumo", "Sumo", SLIME_BALL, null, null, new ArrayList<>(),
                new PotionEffect(PotionEffectType.RESISTANCE, 24000, 4, false, false));
    }

    private static Kit buildffa() {
        List<ItemStack> i = list(
                e(DIAMOND_SWORD, 1, SHARP, 2, UNB, 3),
                e(DIAMOND_PICKAXE, 1, EFF, 3),
                it(SHEARS, 1), it(FISHING_ROD, 1),
                e(BOW, 1, POWER, 1), it(ARROW, 16),
                it(GOLDEN_APPLE, 6), it(ENDER_PEARL, 2), it(WATER_BUCKET, 1),
                it(SANDSTONE, 64), it(SANDSTONE, 64), it(SANDSTONE, 64));
        return kit("buildffa", "Build FFA", SANDSTONE, armor("IRON", PROT, 2), null, i);
    }

    private static Kit gapple() {
        List<ItemStack> i = list(
                e(DIAMOND_SWORD, 1, SHARP, 5, UNB, 3),
                it(ENCHANTED_GOLDEN_APPLE, 8), it(GOLDEN_APPLE, 32), it(COOKED_BEEF, 16),
                e(BOW, 1, POWER, 3, UNB, 3), it(ARROW, 32), it(ENDER_PEARL, 8));
        return kit("gapple", "Gapple", ENCHANTED_GOLDEN_APPLE, armor("NETHERITE", PROT, 3), it(SHIELD, 1), i);
    }

    // --------------------------------------------------------------- helpers

    private static Kit kit(String name, String display, Material icon, ItemStack[] armor, ItemStack off,
                           List<ItemStack> items, PotionEffect... effects) {
        ItemStack[] c = new ItemStack[41];
        for (int i = 0; i < items.size() && i < 36; i++) c[i] = items.get(i);
        if (armor != null) {
            c[36] = armor[0];
            c[37] = armor[1];
            c[38] = armor[2];
            c[39] = armor[3];
        }
        c[40] = off;
        return new Kit(name, display, icon, c, new ArrayList<>(Arrays.asList(effects)));
    }

    private static List<ItemStack> list(ItemStack... a) {
        return new ArrayList<>(Arrays.asList(a));
    }

    private static ItemStack it(Material m, int n) {
        return new ItemStack(m, n);
    }

    private static ItemStack e(Material m, int n, Object... ench) {
        ItemStack s = new ItemStack(m, n);
        for (int i = 0; i < ench.length; i += 2)
            if (ench[i] != null) s.addUnsafeEnchantment((Enchantment) ench[i], (Integer) ench[i + 1]);
        return s;
    }

    /** boots, leggings, chestplate, helmet */
    private static ItemStack[] armor(String type, Enchantment prot, int lvl) {
        String[] parts = {"BOOTS", "LEGGINGS", "CHESTPLATE", "HELMET"};
        ItemStack[] a = new ItemStack[4];
        for (int i = 0; i < 4; i++)
            a[i] = e(Material.valueOf(type + "_" + parts[i]), 1, prot, lvl, UNB, 3, MEND, 1);
        a[0].addUnsafeEnchantment(FF, 4);
        return a;
    }


    private static ItemStack rockets(int n) {
        ItemStack s = new ItemStack(FIREWORK_ROCKET, n);
        FireworkMeta m = (FireworkMeta) s.getItemMeta();
        m.setPower(3);
        s.setItemMeta(m);
        return s;
    }

    private static ItemStack potion(boolean splash, PotionEffectType t, int ticks, int amp, String name, Color color) {
        ItemStack s = new ItemStack(splash ? SPLASH_POTION : POTION);
        PotionMeta m = (PotionMeta) s.getItemMeta();
        m.addCustomEffect(new PotionEffect(t, ticks, amp), true);
        m.setColor(color);
        m.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
        s.setItemMeta(m);
        return s;
    }

    private static void fillSplash(List<ItemStack> l) {
        while (l.size() < 36)
            l.add(potion(true, PotionEffectType.INSTANT_HEALTH, 1, 1, "Splash Healing II", Color.RED));
    }
}
