package dev.pvparena;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

final class KitMenu implements InventoryHolder {

    final List<String> names = new ArrayList<>();
    private final Inventory inv;

    KitMenu(KitManager kits) {
        int n = Math.min(54, kits.all().size());
        int rows = Math.max(1, Math.min(6, (n + 8) / 9));
        inv = Bukkit.createInventory(this, rows * 9, Component.text("PvP Kits"));
        for (Kit k : kits.all()) {
            if (names.size() >= 54) break;
            Material icon = k.icon().isItem() ? k.icon() : Material.CHEST;
            ItemStack it = new ItemStack(icon);
            ItemMeta m = it.getItemMeta();
            m.displayName(Component.text(k.display()).color(NamedTextColor.GOLD)
                    .decoration(TextDecoration.ITALIC, false));
            m.lore(List.of(Component.text("Click to equip").color(NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
            m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            it.setItemMeta(m);
            inv.setItem(names.size(), it);
            names.add(k.name());
        }
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
