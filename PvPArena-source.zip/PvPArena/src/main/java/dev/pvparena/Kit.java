package dev.pvparena;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.List;

/**
 * contents uses PlayerInventory layout: 0-35 hotbar+main, 36 boots, 37 leggings,
 * 38 chestplate, 39 helmet, 40 offhand.
 */
record Kit(String name, String display, Material icon, ItemStack[] contents, List<PotionEffect> effects) {}
