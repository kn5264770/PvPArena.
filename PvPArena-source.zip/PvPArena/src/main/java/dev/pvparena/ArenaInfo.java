package dev.pvparena;

import org.bukkit.Location;

/** Where the arena was built (center, floor level). */
record ArenaInfo(String world, int x, int y, int z) {

    boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        double dx = l.getX() - (x + 0.5);
        double dz = l.getZ() - (z + 0.5);
        double r = ArenaBuilder.OUTER + 4;
        return dx * dx + dz * dz <= r * r
                && l.getY() >= y + ArenaBuilder.BOTTOM
                && l.getY() <= y + ArenaBuilder.TOP;
    }
}
