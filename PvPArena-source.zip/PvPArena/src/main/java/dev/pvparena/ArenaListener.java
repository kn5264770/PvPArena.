package dev.pvparena;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerDropItemEvent;

final class ArenaListener implements Listener {

    private final PvPArenaPlugin plugin;

    ArenaListener(PvPArenaPlugin plugin) {
        this.plugin = plugin;
    }

    private void mark(Location l) {
        if (plugin.inArena(l)) plugin.markDirty(false);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.inArena(e.getEntity().getLocation())) return;
        plugin.markDirty(true); // a match just ended
        if (plugin.getConfig().getBoolean("clean.clear-drops-on-death", true)) {
            e.getDrops().clear();
            e.setDroppedExp(0);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        mark(e.getBlock().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        mark(e.getBlock().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        mark(e.getBlock().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        mark(e.getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        mark(e.getBlock().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        mark(e.getBlock().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent e) {
        mark(e.getEntity().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        mark(e.getPlayer().getLocation());
    }

    // ---- kit menu ----

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof KitMenu menu)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int s = e.getSlot();
        if (s < 0 || s >= menu.names.size()) return;
        Kit k = plugin.kits().get(menu.names.get(s));
        if (k == null) return;
        p.closeInventory();
        plugin.equipKit(p, k);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof KitMenu) e.setCancelled(true);
    }
}
