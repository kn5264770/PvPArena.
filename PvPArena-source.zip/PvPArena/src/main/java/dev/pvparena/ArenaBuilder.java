package dev.pvparena;

import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.Random;

import static org.bukkit.Material.*;

/**
 * Generates the arena as a list of relative block placements.
 * Origin (0,0,0) = arena center at floor level. Entrance bridge is +Z (south),
 * the PVP gate with the crown is at -Z (north).
 */
final class ArenaBuilder {

    static final int R = 24;            // fighting floor radius
    static final int OUTER = R + 15;    // outer wall radius
    static final int CONE = 36;         // depth of the hanging underside
    static final int TOP = 42;          // build height above floor
    static final int BOTTOM = -(10 + CONE);

    int size = 0;
    int[] xs = new int[1 << 18];
    int[] ys = new int[1 << 18];
    int[] zs = new int[1 << 18];
    BlockData[] data = new BlockData[1 << 18];

    private final EnumMap<Material, BlockData> cache = new EnumMap<>(Material.class);
    private final Random rng = new Random(7);

    // ---------------------------------------------------------------- helpers

    private BlockData bd(Material m) {
        return cache.computeIfAbsent(m, Material::createBlockData);
    }

    private void set(int x, int y, int z, BlockData d) {
        if (size == xs.length) {
            int n = size * 2;
            xs = Arrays.copyOf(xs, n);
            ys = Arrays.copyOf(ys, n);
            zs = Arrays.copyOf(zs, n);
            data = Arrays.copyOf(data, n);
        }
        xs[size] = x;
        ys[size] = y;
        zs[size] = z;
        data[size] = d;
        size++;
    }

    private void set(int x, int y, int z, Material m) {
        set(x, y, z, bd(m));
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material m) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    set(x, y, z, m);
    }

    private void fillMix(int x1, int y1, int z1, int x2, int y2, int z2) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    set(x, y, z, wallMat());
    }

    private Material wallMat() {
        int r = rng.nextInt(100);
        if (r < 78) return POLISHED_BLACKSTONE_BRICKS;
        if (r < 90) return CRACKED_POLISHED_BLACKSTONE_BRICKS;
        if (r < 97) return BLACKSTONE;
        return GILDED_BLACKSTONE;
    }

    private static double dist(int x, int z) {
        return Math.sqrt((double) x * x + (double) z * z);
    }

    // ------------------------------------------------------------------ build

    void build() {
        clear();
        cone();
        base();
        floor();
        moat();
        stands();
        wall();
        towers();
        gatehouse();
        dragons();
        carve();
        portal();
        bridges();
        details();
    }

    /** Clear the air space so terrain doesn't poke through. */
    private void clear() {
        int rad = OUTER + 4;
        for (int x = -rad; x <= rad; x++)
            for (int z = -rad; z <= rad; z++)
                if (dist(x, z) <= rad)
                    fill(x, 1, z, x, TOP, z, AIR);
    }

    /** Hanging inverted-cone underside. */
    private void cone() {
        for (int y = -10; y >= BOTTOM; y--) {
            double t = (-10 - y) / (double) CONE;
            double r = OUTER * (1 - t) + 0.5;
            int ri = (int) Math.ceil(r);
            for (int x = -ri; x <= ri; x++)
                for (int z = -ri; z <= ri; z++)
                    if (dist(x, z) <= r) {
                        int n = rng.nextInt(100);
                        set(x, y, z, n < 6 ? MAGMA_BLOCK : n < 30 ? DEEPSLATE_BRICKS : BLACKSTONE);
                    }
        }
    }

    private void base() {
        for (int x = -OUTER; x <= OUTER; x++)
            for (int z = -OUTER; z <= OUTER; z++)
                if (dist(x, z) <= OUTER)
                    for (int y = -9; y <= -1; y++)
                        set(x, y, z, rng.nextInt(5) == 0 ? DEEPSLATE_BRICKS : BLACKSTONE);
    }

    private void floor() {
        for (int x = -R; x <= R; x++)
            for (int z = -R; z <= R; z++) {
                double d = dist(x, z);
                if (d <= R) set(x, 0, z, floorMat(x, z, d));
            }
    }

    private Material floorMat(int x, int z, double d) {
        double th = Math.atan2(z, x);
        if (d <= 1.5) return SHROOMLIGHT;
        if (d <= 10 && d <= 4 + 6 * Math.abs(Math.cos(4 * th))) return RED_NETHER_BRICKS; // 8-point star
        if ((d >= 5.5 && d < 6.5) || (d >= 11.5 && d < 12.5) || (d >= 17.5 && d < 18.5) || d >= R - 1.2)
            return SHROOMLIGHT; // glowing rings (no magma damage)
        int sector = (int) ((th + Math.PI) / (2 * Math.PI) * 24);
        int ring = (int) (d / 3);
        boolean chk = ((ring + sector) & 1) == 0;
        if (chk) return rng.nextInt(10) == 0 ? CRACKED_POLISHED_BLACKSTONE_BRICKS : POLISHED_BLACKSTONE_BRICKS;
        return BLACKSTONE;
    }

    private void moat() {
        for (int x = -(R + 8); x <= R + 8; x++)
            for (int z = -(R + 8); z <= R + 8; z++) {
                double d = dist(x, z);
                if (d > R && d <= R + 8) {
                    fill(x, -8, z, x, -1, z, LAVA);
                    set(x, 0, z, AIR);
                }
            }
    }

    private void stands() {
        for (int x = -(R + 13); x <= R + 13; x++)
            for (int z = -(R + 13); z <= R + 13; z++) {
                double d = dist(x, z);
                if (d > R + 8 && d <= R + 13) {
                    int h = (int) Math.ceil(d - (R + 8));
                    for (int y = 0; y <= h; y++) set(x, y, z, wallMat());
                }
            }
    }

    private boolean nearLavafall(int x, int z) {
        double th = Math.atan2(z, x);
        for (int k = 0; k < 8; k++) {
            double c = Math.toRadians(22.5 + 45 * k);
            double diff = Math.atan2(Math.sin(th - c), Math.cos(th - c));
            if (Math.abs(diff) < 0.05) return true;
        }
        return false;
    }

    private void wall() {
        for (int x = -OUTER; x <= OUTER; x++)
            for (int z = -OUTER; z <= OUTER; z++) {
                double d = dist(x, z);
                if (d > R + 13 && d <= R + 15) {
                    boolean lava = d <= R + 14.3 && nearLavafall(x, z);
                    for (int y = 0; y <= 16; y++) {
                        if (lava && y >= 2 && y <= 15) set(x, y, z, (y % 4 == 0) ? MAGMA_BLOCK : SHROOMLIGHT);
                        else set(x, y, z, wallMat());
                    }
                    int sector = (int) ((Math.atan2(z, x) + Math.PI) / (2 * Math.PI) * 72);
                    if (d > R + 13.5 && sector % 2 == 0) set(x, 17, z, wallMat()); // battlements
                }
            }
    }

    // ---------------------------------------------------------------- towers

    private void towers() {
        int[] angles = {0, 45, 135, 180, 225, 315};
        for (int a : angles) {
            int cx = (int) Math.round(Math.cos(Math.toRadians(a)) * (R + 14.5));
            int cz = (int) Math.round(Math.sin(Math.toRadians(a)) * (R + 14.5));
            tower(cx, cz);
        }
    }

    private void tower(int cx, int cz) {
        fillMix(cx - 2, 0, cz - 2, cx + 2, 20, cz + 2);
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                if (Math.abs(dx) == 2 || Math.abs(dz) == 2) set(cx + dx, 18, cz + dz, RED_NETHER_BRICKS);
        for (int y = 12; y <= 14; y++) {
            set(cx - 2, y, cz, SHROOMLIGHT);
            set(cx + 2, y, cz, SHROOMLIGHT);
            set(cx, y, cz - 2, SHROOMLIGHT);
            set(cx, y, cz + 2, SHROOMLIGHT);
        }
        fill(cx - 3, 21, cz - 3, cx + 3, 22, cz + 3, BLACKSTONE);
        fill(cx - 1, 23, cz - 1, cx + 1, 25, cz + 1, POLISHED_BLACKSTONE_BRICKS);
        fill(cx, 26, cz, cx, 32, cz, POLISHED_BLACKSTONE_BRICKS);
        set(cx, 33, cz, GOLD_BLOCK);
        set(cx - 3, 23, cz - 3, LANTERN);
        set(cx + 3, 23, cz - 3, LANTERN);
        set(cx - 3, 23, cz + 3, LANTERN);
        set(cx + 3, 23, cz + 3, LANTERN);
    }

    // -------------------------------------------------------------- gatehouse

    private static final String[] GLYPH_P = {"####.", "#...#", "#...#", "####.", "#....", "#....", "#...."};
    private static final String[] GLYPH_V = {"#...#", "#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#.."};

    private void gatehouse() {
        int back = -(R + 16);
        int front = -(R + 11);
        fillMix(-10, 0, back, 10, 19, front);
        fillMix(-7, 20, back, 7, 27, front);
        fill(-9, 11, front, 9, 19, front, BLACKSTONE); // sign backing

        int lz = -(R + 10); // letters sit just in front of the facade
        letter(GLYPH_P, -8, lz);
        letter(GLYPH_V, -2, lz);
        letter(GLYPH_P, 4, lz);

        // crown
        int cz = -(R + 12);
        fill(-5, 28, cz, 5, 29, cz, GOLD_BLOCK);
        int[][] pts = {{-4, 2}, {-2, 1}, {0, 3}, {2, 1}, {4, 2}};
        for (int[] pt : pts) fill(pt[0], 30, cz, pt[0], 29 + pt[1], cz, GOLD_BLOCK);
        set(0, 28, cz, LAPIS_BLOCK);

        tower(-12, -(R + 13));
        tower(12, -(R + 13));
    }

    private void letter(String[] g, int x0, int z) {
        for (int r = 0; r < g.length; r++)
            for (int c = 0; c < g[r].length(); c++)
                if (g[r].charAt(c) == '#') set(x0 + c, 18 - r, z, REDSTONE_BLOCK);
    }

    // ---------------------------------------------------------------- dragons

    private void dragons() {
        dragon(-17, -(R + 11));
        dragon(17, -(R + 11));
    }

    /** Dragon head statue facing +Z (toward the arena). */
    private void dragon(int cx, int cz) {
        fillMix(cx - 2, 0, cz - 2, cx + 2, 19, cz + 2);
        fill(cx - 2, 20, cz - 2, cx + 2, 22, cz + 2, BLACKSTONE);
        for (int i = 0; i < 5; i++) {
            int y = 23 + i, z = cz + i;
            fillMix(cx - 1, y, z - 1, cx + 1, y + 1, z + 1);
            if (i > 0) set(cx, y + 2, z - 1, POLISHED_BLACKSTONE_BRICK_WALL);
        }
        int hz = cz + 5;
        fill(cx - 1, 28, hz, cx + 1, 29, hz + 4, BLACKSTONE);           // upper jaw
        fill(cx - 1, 26, hz - 1, cx + 1, 26, hz + 4, BLACKSTONE);       // lower jaw
        fill(cx, 27, hz + 1, cx, 27, hz + 3, RED_CONCRETE);             // mouth glow
        set(cx - 2, 29, hz + 1, REDSTONE_BLOCK);                        // eyes
        set(cx + 2, 29, hz + 1, REDSTONE_BLOCK);
        set(cx - 1, 30, hz, POLISHED_BLACKSTONE_BRICK_WALL);            // horns
        set(cx + 1, 30, hz, POLISHED_BLACKSTONE_BRICK_WALL);
        set(cx - 1, 31, hz - 1, POLISHED_BLACKSTONE_BRICK_WALL);
        set(cx + 1, 31, hz - 1, POLISHED_BLACKSTONE_BRICK_WALL);
    }

    // ----------------------------------------------------- carving / bridges

    private void carve() {
        fill(-3, 1, R + 9, 3, 9, R + 16, AIR);          // south entrance tunnel
        fill(-3, 1, -(R + 13), 3, 8, -(R + 8), AIR);    // north gate alcove
    }

    private void portal() {
        int z = -(R + 14);
        fill(-3, 0, z, 3, 6, z, CRYING_OBSIDIAN);
        fill(-2, 1, z, 2, 5, z, PURPLE_STAINED_GLASS); // decorative, not a real portal
    }

    private void bridges() {
        for (int s = 1; s >= -1; s -= 2) {
            int z1 = s * (R + 1);
            int z2 = s > 0 ? R + 19 : -(R + 13);
            for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                for (int x = -3; x <= 3; x++)
                    set(x, 0, z, Math.abs(x) == 3 ? POLISHED_BLACKSTONE_BRICKS : BLACKSTONE);
                for (int x = -1; x <= 1; x++) set(x, 1, z, RED_CARPET);
                set(-3, 1, z, POLISHED_BLACKSTONE_BRICK_WALL);
                set(3, 1, z, POLISHED_BLACKSTONE_BRICK_WALL);
                if (Math.floorMod(z, 4) == 0) {
                    set(-3, 2, z, LANTERN);
                    set(3, 2, z, LANTERN);
                }
            }
        }
    }

    // ---------------------------------------------------------------- details

    private void details() {
        // lantern posts around the platform edge
        for (int k = 0; k < 16; k++) {
            double a = k * Math.PI / 8;
            int x = (int) Math.round(Math.cos(a) * (R - 0.5));
            int z = (int) Math.round(Math.sin(a) * (R - 0.5));
            if (Math.abs(x) <= 4) continue; // keep bridge ends clear
            set(x, 1, z, POLISHED_BLACKSTONE_BRICK_WALL);
            set(x, 2, z, LANTERN);
        }
        // banners on the gatehouse facade
        int[] bx = {-8, -5, 5, 8};
        for (int x : bx) banner(x, 9, -(R + 10), BlockFace.SOUTH);
        // banners on the east / west walls
        banner(36, 8, -4, BlockFace.WEST);
        banner(36, 8, 4, BlockFace.WEST);
        banner(35, 8, -9, BlockFace.WEST);
        banner(35, 8, 9, BlockFace.WEST);
        banner(-36, 8, -4, BlockFace.EAST);
        banner(-36, 8, 4, BlockFace.EAST);
        banner(-35, 8, -9, BlockFace.EAST);
        banner(-35, 8, 9, BlockFace.EAST);
    }

    private void banner(int x, int y, int z, BlockFace face) {
        Directional d = (Directional) RED_WALL_BANNER.createBlockData();
        d.setFacing(face);
        set(x, y, z, d);
    }
}
