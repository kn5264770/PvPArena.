package dev.pvparena;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public final class PvPArenaPlugin extends JavaPlugin {

    private record Saved(int x, int y, int z, BlockData old) {}
    private record Undo(World world, ArenaInfo info, List<Saved> blocks) {}

    private final Map<UUID, Undo> undos = new HashMap<>();
    private final Random random = new Random();

    private KitManager kits;
    private ArenaInfo arena;
    private ArenaBuilder cachedBuilder;
    private File arenaFile;

    private boolean busy = false;
    private boolean dirty = false;       // arena was used / changed
    private boolean matchEnded = false;  // someone died inside
    private long readySince = -1;

    // ------------------------------------------------------------- lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        arenaFile = new File(getDataFolder(), "arena.yml");
        kits = new KitManager(this);
        kits.load();
        loadArena();
        getServer().getPluginManager().registerEvents(new ArenaListener(this), this);
        getServer().getScheduler().runTaskTimer(this, this::tickAuto, 20L, 20L);
    }

    KitManager kits() {
        return kits;
    }

    private void loadArena() {
        arena = null;
        if (!arenaFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(arenaFile);
        String w = y.getString("world");
        if (w != null) arena = new ArenaInfo(w, y.getInt("x"), y.getInt("y"), y.getInt("z"));
    }

    private void saveArena() {
        try {
            if (arena == null) {
                //noinspection ResultOfMethodCallIgnored
                arenaFile.delete();
                return;
            }
            YamlConfiguration y = new YamlConfiguration();
            y.set("world", arena.world());
            y.set("x", arena.x());
            y.set("y", arena.y());
            y.set("z", arena.z());
            getDataFolder().mkdirs();
            y.save(arenaFile);
        } catch (IOException e) {
            getLogger().warning("Could not save arena.yml: " + e.getMessage());
        }
    }

    boolean inArena(Location l) {
        return arena != null && arena.contains(l);
    }

    void markDirty(boolean matchEnd) {
        dirty = true;
        if (matchEnd) matchEnded = true;
    }

    private ArenaBuilder builder() {
        if (cachedBuilder == null) {
            cachedBuilder = new ArenaBuilder();
            cachedBuilder.build();
        }
        return cachedBuilder;
    }

    // -------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("kit")) return kitCommand(sender, args);
        return arenaCommand(sender, args);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("kit")) {
            if (args.length == 1) {
                out.addAll(List.of("list", "random"));
                if (sender.hasPermission("pvparena.admin")) out.addAll(List.of("create", "delete", "give", "reload"));
                out.addAll(kits.names());
            } else if (args.length == 2 && (args[0].equalsIgnoreCase("delete"))) {
                out.addAll(kits.names());
            } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
                out.addAll(kits.names());
            }
            String last = args[args.length - 1].toLowerCase(Locale.ROOT);
            out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
            return out;
        }
        if (args.length == 1) {
            for (String s : List.of("build", "undo", "reset", "clean", "info", "reload"))
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }

    private boolean arenaCommand(CommandSender sender, String[] args) {
        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "build";
        switch (sub) {
            case "build", "undo" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                if (busy) {
                    sender.sendMessage("An arena job is already running, wait for it to finish.");
                    return true;
                }
                if (sub.equals("build")) build(p);
                else undo(p);
            }
            case "reset" -> {
                if (busy) sender.sendMessage("An arena job is already running, wait for it to finish.");
                else resetArena(sender);
            }
            case "clean" -> {
                if (arena == null) sender.sendMessage("No arena built yet.");
                else {
                    int n = cleanEntities();
                    sender.sendMessage("Removed " + n + " leftover entities (items, arrows, crystals...).");
                }
            }
            case "info" -> {
                if (arena == null) {
                    sender.sendMessage("No arena built yet. Stand where you want it and run /pvparena.");
                } else {
                    sender.sendMessage("Arena: world " + arena.world() + " center " + arena.x() + " "
                            + (arena.y() + 1) + " " + arena.z() + ", players inside: " + playersInArena()
                            + ", auto-reset: " + getConfig().getBoolean("auto-reset.enabled", true));
                }
            }
            case "reload" -> {
                reloadConfig();
                kits.load();
                sender.sendMessage("PvPArena config and kits reloaded.");
            }
            default -> sender.sendMessage("Usage: /pvparena [build|undo|reset|clean|info|reload]");
        }
        return true;
    }

    private boolean kitCommand(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Kits: " + String.join(", ", kits.names()));
                return true;
            }
            p.openInventory(new KitMenu(kits).getInventory());
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> sender.sendMessage("Kits: " + String.join(", ", kits.names()));
            case "random" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                List<String> n = kits.names();
                if (n.isEmpty()) sender.sendMessage("No kits.");
                else equipKit(p, kits.get(n.get(random.nextInt(n.size()))));
            }
            case "create" -> {
                if (!sender.hasPermission("pvparena.admin")) {
                    sender.sendMessage("No permission.");
                    return true;
                }
                if (!(sender instanceof Player p) || args.length < 2) {
                    sender.sendMessage("Usage: /kit create <name> (saves your current inventory + effects)");
                    return true;
                }
                String name = args[1].toLowerCase(Locale.ROOT);
                if (List.of("list", "random", "create", "delete", "give", "reload").contains(name)) {
                    sender.sendMessage("That name is reserved.");
                    return true;
                }
                kits.create(name, p);
                sender.sendMessage("Kit '" + name + "' saved from your inventory.");
            }
            case "delete" -> {
                if (!sender.hasPermission("pvparena.admin")) {
                    sender.sendMessage("No permission.");
                    return true;
                }
                if (args.length < 2) sender.sendMessage("Usage: /kit delete <name>");
                else sender.sendMessage(kits.delete(args[1]) ? "Kit deleted." : "No such kit.");
            }
            case "give" -> {
                if (!sender.hasPermission("pvparena.admin")) {
                    sender.sendMessage("No permission.");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage("Usage: /kit give <player> <kit>");
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                Kit k = kits.get(args[2]);
                if (t == null || k == null) {
                    sender.sendMessage("Unknown player or kit.");
                    return true;
                }
                kits.apply(t, k, getConfig().getBoolean("kits.clear-effects", true));
                sender.sendMessage("Gave " + k.display() + " to " + t.getName() + ".");
                t.sendMessage("You received the " + k.display() + " kit.");
            }
            case "reload" -> {
                if (!sender.hasPermission("pvparena.admin")) {
                    sender.sendMessage("No permission.");
                    return true;
                }
                kits.load();
                sender.sendMessage("Kits reloaded.");
            }
            default -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                Kit k = kits.get(sub);
                if (k == null) sender.sendMessage("No such kit. Use /kit list.");
                else equipKit(p, k);
            }
        }
        return true;
    }

    void equipKit(Player p, Kit k) {
        if (getConfig().getBoolean("kits.require-arena", false) && !inArena(p.getLocation())) {
            p.sendMessage("You can only equip kits inside the arena.");
            return;
        }
        if (p.getGameMode() == GameMode.SPECTATOR) {
            p.sendMessage("You can't equip a kit in spectator mode.");
            return;
        }
        kits.apply(p, k, getConfig().getBoolean("kits.clear-effects", true));
        p.sendMessage("Equipped kit: " + k.display());
    }

    // ----------------------------------------------------------- build / undo

    private void build(Player p) {
        World w = p.getWorld();
        final int ox = p.getLocation().getBlockX();
        final int oy = p.getLocation().getBlockY() - 1; // arena floor = block under your feet
        final int oz = p.getLocation().getBlockZ();

        if (oy + ArenaBuilder.BOTTOM < w.getMinHeight() || oy + ArenaBuilder.TOP >= w.getMaxHeight()) {
            p.sendMessage("Not enough vertical space here. Stand at least "
                    + (-ArenaBuilder.BOTTOM) + " blocks above the world bottom and "
                    + ArenaBuilder.TOP + " below the height limit.");
            return;
        }

        ArenaBuilder b = builder();
        List<Saved> saved = new ArrayList<>();
        p.sendMessage("Building PvP arena (" + b.size + " block ops)...");
        runPlacement(b, w, ox, oy, oz, saved, p, () -> {
            ArenaInfo info = new ArenaInfo(w.getName(), ox, oy, oz);
            arena = info;
            saveArena();
            undos.put(p.getUniqueId(), new Undo(w, info, saved));
            dirty = false;
            matchEnded = false;
            readySince = -1;
            p.sendMessage("PvP arena done! /pvparena reset restores it, /pvparena undo removes it, /kit gives gear.");
        });
    }

    private void undo(Player p) {
        Undo u = undos.remove(p.getUniqueId());
        if (u == null) {
            p.sendMessage("Nothing to undo (undo data is kept until the server restarts).");
            return;
        }
        busy = true;
        p.sendMessage("Removing arena...");
        final int perTick = getConfig().getInt("blocks-per-tick", 5000);
        new BukkitRunnable() {
            int i = u.blocks().size() - 1;

            @Override
            public void run() {
                int n = 0;
                while (i >= 0 && n < perTick) {
                    Saved s = u.blocks().get(i--);
                    u.world().getBlockAt(s.x(), s.y(), s.z()).setBlockData(s.old(), false);
                    n++;
                }
                if (i < 0) {
                    cancel();
                    busy = false;
                    if (u.info().equals(arena)) {
                        arena = null;
                        saveArena();
                    }
                    p.sendMessage("Arena removed.");
                }
            }
        }.runTaskTimer(this, 1L, 1L);
    }

    // ------------------------------------------------------- reset / cleaning

    /** Restore every arena block to its original state and delete leftovers. */
    private void resetArena(CommandSender who) {
        if (arena == null) {
            if (who != null) who.sendMessage("No arena built yet. Use /pvparena build.");
            return;
        }
        World w = Bukkit.getWorld(arena.world());
        if (w == null) {
            if (who != null) who.sendMessage("The arena's world isn't loaded.");
            return;
        }
        ArenaBuilder b = builder();
        dirty = false;
        matchEnded = false;
        readySince = -1;
        tellArena("Arena is resetting...");
        if (getConfig().getBoolean("clean.clear-entities", true)) cleanEntities();
        runPlacement(b, w, arena.x(), arena.y(), arena.z(), null, who, () -> {
            if (getConfig().getBoolean("clean.clear-entities", true)) cleanEntities();
            tellArena("Arena reset - it's like new!");
            if (who != null) who.sendMessage("Arena reset complete.");
        });
    }

    private int cleanEntities() {
        if (arena == null) return 0;
        World w = Bukkit.getWorld(arena.world());
        if (w == null) return 0;
        double midY = arena.y() + (ArenaBuilder.TOP + ArenaBuilder.BOTTOM) / 2.0;
        double halfY = (ArenaBuilder.TOP - ArenaBuilder.BOTTOM) / 2.0 + 5;
        double r = ArenaBuilder.OUTER + 6;
        Location c = new Location(w, arena.x() + 0.5, midY, arena.z() + 0.5);
        int n = 0;
        for (Entity e : w.getNearbyEntities(c, r, halfY, r)) {
            if (e instanceof Player) continue;
            if (e instanceof Item || e instanceof ExperienceOrb || e instanceof Projectile
                    || e instanceof EnderCrystal || e instanceof TNTPrimed || e instanceof FallingBlock
                    || e instanceof AreaEffectCloud) {
                e.remove();
                n++;
            }
        }
        return n;
    }

    private int playersInArena() {
        int n = 0;
        for (Player p : Bukkit.getOnlinePlayers())
            if (inArena(p.getLocation()) && p.getGameMode() != GameMode.SPECTATOR && !p.isDead()) n++;
        return n;
    }

    private void tellArena(String msg) {
        for (Player p : Bukkit.getOnlinePlayers())
            if (inArena(p.getLocation())) p.sendMessage(msg);
    }

    /** Runs every second: resets the arena once a match is over. */
    private void tickAuto() {
        if (arena == null || busy || !dirty || !getConfig().getBoolean("auto-reset.enabled", true)) {
            readySince = -1;
            return;
        }
        int count = playersInArena();
        boolean ready = count == 0 || (matchEnded && count <= 1);
        if (!ready) {
            readySince = -1;
            return;
        }
        long now = System.currentTimeMillis();
        if (readySince < 0) readySince = now;
        long delay = getConfig().getLong("auto-reset.delay-seconds", 10) * 1000L;
        if (now - readySince >= delay) resetArena(null);
    }

    // ------------------------------------------------------ placement runner

    /**
     * Places every op in b relative to (ox,oy,oz), a few thousand per tick.
     * Only blocks that actually differ are changed, so a reset of a barely
     * touched arena is fast. If record != null, old blocks are saved for undo.
     */
    private void runPlacement(ArenaBuilder b, World w, int ox, int oy, int oz,
                              List<Saved> record, CommandSender notify, Runnable done) {
        busy = true;
        final int perTick = getConfig().getInt("blocks-per-tick", 5000);
        final int maxScan = getConfig().getInt("scan-per-tick", 40000);
        new BukkitRunnable() {
            int i = 0;
            int lastPct = 0;

            @Override
            public void run() {
                int sets = 0, scanned = 0;
                while (i < b.size && sets < perTick && scanned < maxScan) {
                    scanned++;
                    Block blk = w.getBlockAt(ox + b.xs[i], oy + b.ys[i], oz + b.zs[i]);
                    BlockData nd = b.data[i];
                    BlockData old = blk.getBlockData();
                    if (!old.equals(nd)) {
                        if (record != null) record.add(new Saved(blk.getX(), blk.getY(), blk.getZ(), old));
                        blk.setBlockData(nd, false);
                        sets++;
                    }
                    i++;
                }
                int pct = (int) (100L * i / Math.max(1, b.size));
                if (notify != null && pct >= lastPct + 25 && i < b.size) {
                    lastPct = pct - (pct % 25);
                    notify.sendMessage("Arena " + lastPct + "%");
                }
                if (i >= b.size) {
                    cancel();
                    busy = false;
                    done.run();
                }
            }
        }.runTaskTimer(this, 1L, 1L);
    }
}
